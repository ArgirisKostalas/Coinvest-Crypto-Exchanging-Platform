package core.CoinvestEE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoinvestEeApplicationTests {

	@Test
	void contextLoads() {
	}

}
