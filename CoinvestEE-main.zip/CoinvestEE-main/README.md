# CoinvestEE
Cryptocurrency Stock Exchange Market Demo Web Application based on Spring Boot MVC
This is a Demo Application that utilises the capabilities of Spring Framework combined with Angular JS. It is a work in progress so a lot
of features might be dummy. 
